package com;

public class Guitar extends Instrument {
	public void play() {
		System.out.println("Guitar is playing  tin  tin  tin");

	}

}
