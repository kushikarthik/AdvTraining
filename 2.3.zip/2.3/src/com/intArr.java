package com;

import java.util.Arrays;

public class intArr {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]= {3,2,4,5,6,4,5,7,3,2,3,4,7,1,2,0,0,0};
		
		a[15]=a[0]+a[14];
		System.out.println(a[15]);
		System.out.println("...................");
		int sum=0;
		int i=0;
		while(i<a.length) {
			sum=sum+a[i];
			i++;
		}
		int avg=(sum/a.length);
		a[16]=avg;
		System.out.println(a[16]);
		System.out.println("...................");
		
		 Arrays.sort(a);
		 int b=a[0];
		 a[17]=b;
		 System.out.println(a[17]);
		
		
		
		
	}

}
