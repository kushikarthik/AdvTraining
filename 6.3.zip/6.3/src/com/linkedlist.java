package com;

public class linkedlist {
	int empno;
	String empname;
	String address;
	public linkedlist(int empno, String empname, String address) {
		super();
		this.empno = empno;
		this.empname = empname;
		this.address = address;
	
	}
	
	void display() {
		System.out.println(empno+" "+empname+" "+address);
	}
	public static void main(String[] args) {
		linkedlist ll1=new linkedlist(1, "Amal", "Hyd");
		linkedlist ll2=new linkedlist(2, "Sai", "Goa");
		linkedlist ll3=new linkedlist(3, "Ravi", "Del");
		linkedlist ll4=new linkedlist(4, "Raju", "Mum");
		ll2.display();
		
	}
}

