
package com;

import java.util.Scanner;

public class Rectangle {
    int length; 
    int breadth; 
    int area; 
    int perimeter;

    void input() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the length of a rectangle ");
        length = sc.nextInt();
        System.out.print("Enter the breadth of a rectangle ");
        breadth = sc.nextInt();
    }

    void calculate() {
        area = length * breadth;
        perimeter = 2 * (length + breadth);
    }

    void display() {
        System.out.println("Area of Rectangle is " + area);
        System.out.println("Perimeter of Rectangle is " + perimeter);
    }

    public static void main(String args[]) {
        Rectangle rec = new Rectangle();
        rec.input();
        rec.calculate();
        rec.display();
    }
}
