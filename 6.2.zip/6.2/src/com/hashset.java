package com;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Objects;

class Product
{
	int id;
	String name;
	public Product(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}
	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + "]";
	}
	@Override
	public int hashCode() {
		return Objects.hash(id, name);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Product other = (Product) obj;
		return id == other.id && Objects.equals(name, other.name);
	}
	
	
	
	
	
}
	


public class hashset {
	private static int id;

	public static void main(String[] args) {
		
		HashSet<Product> set = new HashSet<Product>();	
		set.add(new Product(1, "Maruthi 800"));
		set.add(new Product(2, "Maruthi Zen"));
		set.add(new Product(3, "Maruthi Dezire"));
		set.add(new Product(4, "Maruthi Alto"));
		Iterator<Product> it = set.iterator();
		 
        while (it.hasNext())
        {
            Product pd = (Product) it.next();
 
            System.out.println(pd);
        }
        System.out.println("After deleting");
        
       Product key=new Product(1, "Maruthi 800");
       set.remove(key);
       for(Product pd:set) {
    	   System.out.println(pd);
       }
		
	}
}
