package com;

import java.util.Scanner;

public class CmdLineArg {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter string");
		String str=sc.next();
		System.out.println(str.length());
		System.out.println(str.toUpperCase());
		String rev = "";
		int len=str.length();
		for(int i=len-1;i>=0;i--)
		{
			rev=rev+str.charAt(i);
			
		}
		if(str.equals(rev))
			System.out.println("is Palindrome");
		else
			System.out.println("not a palindrome");
		
	}
}
