package com;

import java.util.HashMap;
import java.util.Scanner;

public class Repeat {
	 public static void main(String[] args) {
		 
	        Scanner sc = new Scanner(System.in);
	        System.out.println("enter length of array ");
	        int[] arr = new int[sc.nextInt()];
	        System.out.println("enter values ");
	        for (int i = 0; i < arr.length; i++) {
	            arr[i] = sc.nextInt();
	            
	        }
	        HashMap<Integer, Integer> rep = solveIterative(arr);
	 
	        for(int value : rep.keySet())
	        {
	            System.out.println(value + " occurs " + rep.get(value)+ " times");
	        }
	 
	    }
	 
	    public static HashMap<Integer, Integer> solveIterative(int[] arr)
	    {
	        HashMap<Integer, Integer> rep = new HashMap<>();
	        for(int value : arr)
	        {
	            if(!rep.containsKey(value))
	            {
	                rep.put(value, 1);
	            }
	            else {
	                rep.put(value, rep.get(value)+1);
	            }
	        }   
	        return rep;
	    
	    }

}
