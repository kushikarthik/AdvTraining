package com;

public class MedicineInfo {
	public void displayLabel() {
		System.out.println("Company : Sun Pharma");
		System.out.println("Address : Hyderabad");
	}
}

class Tablet extends MedicineInfo {

	public void displayLabel() {
		System.out.println("keep it in cool dry place");
	}
}

class Syrup extends MedicineInfo {
	public void displayLabel() {
		System.out.println("Ask your Physician");
	}
}

class Ointment extends MedicineInfo {
	public void displayLabel() {
		System.out.println("keep it away from your eyes");
	}

}
