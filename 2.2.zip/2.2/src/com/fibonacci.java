package com;

import java.util.Scanner;

public class fibonacci {
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("enter 1st 2 numbers");
		int a=sc.nextInt();
		int b=sc.nextInt();
		System.out.println("enter n value");
		int n=sc.nextInt();
		for(int i=1;i<=n;++i) {
			System.out.print(a + " ");
			int c=a+b;
			a=b;
			b=c;
			
		}
		
		
		
		
		
		
	}

}
