package com;

public class StringHandling {
	public static void main(String[] args) {
	    String txt = "JAVA is Simple";
	    System.out.println(txt.toUpperCase());
	    System.out.println(txt.toLowerCase());
	    char[] c=txt.toCharArray();
	    for (int i=0; i < c.length; i++)
	    	{
	           if(c[i] != ' ' && (i == 0 || c[i-1] == ' ')) 
	           	{
	        	   System.out.print(c[i]);
	        	  
	           	}
	           
	      }
	    	System.out.println();
	    
	      String[] str="JAVA is Simple".split("\\s");
	      String reversedString = "";
	      for (int i = 0; i < str.length; i++) { 
	              if (i == str.length - 1) 
	                reversedString = str[i] + reversedString; 
	              else
	                reversedString = " " + str[i] + reversedString; 
	          } 
	      System.out.println( reversedString );
	      
	      String reverse="";
	      for(String s:str)
	      {
	    	  StringBuilder sb=new StringBuilder(s);  
	          sb.reverse();  
	          reverse+=sb.toString()+" ";   
	      }
	      System.out.println(reverse.trim());
	      
	      System.out.println(txt.replace(" ", "").length());
	      
	
	
	
	
	}
		
	      
	    
	    
}


