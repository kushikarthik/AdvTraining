package com;

import java.util.Scanner;
import java.util.Vector;

public class Breakdown {
	static int a[] = { 1, 2, 5, 10, 20, 50, 100, 500, 1000 };
	static int n = a.length;

	static void find(int V) {
		Vector<Integer> ans = new Vector<>();

		for (int i = n - 1; i >= 0; i--) {

			while (V >= a[i]) {
				V -= a[i];
				ans.add(a[i]);
			}
		}

		for (int i = 0; i < ans.size(); i++) {
			System.out.print(" " + ans.elementAt(i));

		}

	}

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the Number");
		int n = scanner.nextInt();

		System.out.print(" Breakdown " + n + ": ");
		find(n);
	}

}
