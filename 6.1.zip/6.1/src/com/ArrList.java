package com;
import java.util.ArrayList;

public class ArrList {
	 public static void main(String[] args){
	      ArrayList <String> list = new ArrayList<String>();
	      list.add("Amal");
	      list.add("Sai");
	      list.add("Raju");
	      list.add("Ravi");
	      list.add("Ram");
	      for (String element : list){
	          if (element.contains("Amal")){
	                System.out.println(element);
	          }
	           
	          
	       
	        }
	      
	      }
	      
	      
	      
	 }
